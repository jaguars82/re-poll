import { createApp } from 'vue'
import Poll from './Poll.vue'

createApp(Poll).mount('#app')
